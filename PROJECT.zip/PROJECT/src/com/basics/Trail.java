package com.basics;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Trail {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		System.out.println("HELLO");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
		Statement s=con.createStatement();
		//int a=s.executeUpdate("insert into consumer values (1,'project','qwerty',12345678,'abc colony')");
		//System.out.println(a);
		//int b=s.executeUpdate("insert into seller values (1,'project1','asdfgh',098765432,'xyz colony')");
		//System.out.println(b);

		//int c=s.executeUpdate("insert into  items  values(1,'trail',0,1,'t','q','qw','intial')");
		//System.out.println(c);   

		//int d=s.executeUpdate("insert into cart values (1,1,1,1)");
		//System.out.println(d);

		int i=s.executeUpdate("delete items where id=1");
		System.out.println(i);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
		
