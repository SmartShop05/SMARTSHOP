package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class status
 */
@WebServlet("/status1")
public class status1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public status1() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}

	// this podt will set order status to return or cancel by consumer
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
			Statement st=con.createStatement();
			PreparedStatement ps=con.prepareStatement("update orders set status=? where id=?");
			ps.setString(1, request.getParameter("sub"));
			ps.setInt(2, Integer.parseInt(request.getParameter("id")));
		int re=	ps.executeUpdate();
		if(re==1) {
			p.print("status changed");
			p.print("<<meta http-equiv=\"refresh\" content=\"1;URL=Myorders.jsp\" />>");
}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
