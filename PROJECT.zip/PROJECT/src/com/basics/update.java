package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/update")
public class update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public update() {
        super();
        
    }

	// this post method updates product details by the seller
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter p=response.getWriter();
		String a=request.getParameter("pid");
	p.print("<html>");
	p.print("<form action=\"update\" method=\"post\">");
	p.print("Product Name:<input type=\"text\" name=\"name\">");
	p.print("Product price:<input type=\"text\" name=\"price\">");
	p.print("Product description:<input type=\"text\" name=\"desc\">");
	p.print("<input type=\"hidden\" name=\"pid\" value=\""+a+"\">");
	
	p.print("<input type=\"submit\" value=\"Update\">");
	p.print("</form>");
	p.print("</html>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  response.setContentType("text/html");
	  PrintWriter p=response.getWriter();
	  int id=Integer.parseInt(request.getParameter("pid"));
	   try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
		PreparedStatement ps=con.prepareStatement("update items set name=?,price=?,description=? where id=?");
		ps.setString(1, request.getParameter("name"));
		ps.setInt(2, Integer.parseInt(request.getParameter("price")));
		ps.setString(3, request.getParameter("desc"));
		ps.setInt(4, Integer.parseInt(request.getParameter("pid")));
		int i=ps.executeUpdate();
		if(i==1) {
			p.print("successfully updated");
			p.print("<<meta http-equiv=\"refresh\" content=\"1;URL=seller.jsp\" />>");
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	}

}
