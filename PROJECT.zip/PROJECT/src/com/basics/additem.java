package com.basics;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/additem")
@MultipartConfig
public class additem extends HttpServlet { 
	private static final long serialVersionUID = 1L;
	private Connection con;
	private Statement st;
	private PreparedStatement ps; 
	private ResultSet rs;
	 InputStream is;
	 OutputStream os;
	public void init() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
			st=con.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
	// this post methods retrive product data from additems.jsp insert into database  creates uploads product image into lib folder


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String type=request.getParameter("type");
		String user=request.getParameter("seller");
				Part file=request.getPart("photo");
				int id12=Integer.parseInt(user);
		
		if (file!=null) {
            // prints out some information for debugging
			
			
            System.out.println(file.getName());
            System.out.println(file.getSize());
            System.out.println(file.getContentType());
           
             }
		 
		 
		
		
		 	
		
		System.out.println(file.getName());
        System.out.println(file.getSize());
        System.out.println(file.getContentType());
		
		
		
		
		
		
		
			try {
				
				
			if(id12!=0) {
				int id=id12;
			
				ps=con.prepareStatement("select Max(id) from items");
				ResultSet rs=ps.executeQuery();
			    
			  
				 		
				ps=con.prepareStatement("insert into items values (?,?,?,?,?,?,?,?)");
			
					if(rs.next()) {
						int i=rs.getInt(1);
						i+=1;
						
						
						   is=file.getInputStream();
						     String path="C:/Users/veerabathini.udaysai/OneDrive - HCL Technologies Ltd/Desktop/Uday.java/PROJECT/WebContent/lib/"+(i)+".jpg";
							 
							 FileOutputStream os= new FileOutputStream(path);
							 
							 
							 		 byte[] by= new byte[is.available()];
							 		 
							 		 
							 		 
							 		 is.read(by);
							 		 
							 		os.write(by);
							 		
							 		os.close();
			 
						 
						p.print("s2");
					ps.setInt(1, i);
					ps.setString(2,name);
					ps.setString(3,price);
					ps.setLong(4,id);
					ps.setString(5,type);
					if(is!=null) {
					
						ps.setString(6,path);
			            ps.setString(7,file.getName());
					}
					ps.setString(8,request.getParameter("desc"));
				
					int s=ps.executeUpdate();
					//if product details is uploaded into database then it will show successfully added .
					if(s==1) {
						System.out.println("Successfully added");
					}
				
					}// if seller is not log in then it will redirect to login page
					}
					
					else {
						p.print("<html>");
						p.print("please login first");
						p.print("<<meta http-equiv=\\\"refresh\\\" content=\\\"5000;URL=addItem.html.html\\\" />>");
						p.print("</html>");
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
		
		
				// TODO Auto-generated catch block
				
			 
		
	

}
}
