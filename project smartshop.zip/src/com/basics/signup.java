package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/signup")
public class signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	private Statement st;
	private PreparedStatement ps;
   
	public void init() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
			st=con.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	//this method  saves user information into database
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p= response.getWriter();
		String type=request.getParameter("type");
		String name=request.getParameter("ft");
		String password=request.getParameter("ps");
		String phoneNo=request.getParameter("pn");
		String address=request.getParameter("ad");
		
		try {
			ps=con.prepareStatement("select Max(id) from "+type);
			
		     ResultSet rs=ps.executeQuery();
		     p.print(type);
			ps=con.prepareStatement("insert into "+type+" values (?,?,?,?,?)");
			if(rs.next()) {
				int i=rs.getInt(1);
				i+=1;
			
			
			ps.setInt(1, i);
			ps.setString(2,name);
			ps.setString(3,password);
			ps.setString(4,phoneNo);
			ps.setString(5,address);
			
			int a=ps.executeUpdate();
			
			p.print(a+"successfully registered");}
			p.print("<html>");
			p.print("<<meta http-equiv=\"refresh\" content=\"0;URL=log.html\" />>");
			
			p.print("</html>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
