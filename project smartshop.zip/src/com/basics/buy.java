package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class buy
 */
@WebServlet("/buy")
public class buy extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public buy() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}

	// this method will add ordered details into database
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		int pid=Integer.parseInt(request.getParameter("pid"));
		int sid=Integer.parseInt(request.getParameter("sid"));
		int cid=logi.getId();
		// if user is not logged in then it will redirect to log in page
	 	if(cid==0) {
	 		p.print("please login ");
	 		p.print("<<meta http-equiv=\"refresh\" content=\"3;URL=log.html\" />>");
	 	}
	 // this else method enters order details into database.
	 	else {
	 		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
				Statement st=con.createStatement();
				ResultSet res=st.executeQuery("select max(id) from orders");
				while(res.next()) {
					int id=res.getInt(1);
					id++;
				
				PreparedStatement ps=con.prepareStatement("insert into orders values(?,?,?,?,?)");
				ps.setInt(1, pid);
				ps.setInt(2, cid);
				ps.setInt(3, sid);
				ps.setString(4,"ordered");
				ps.setInt(5, id);
				int r=ps.executeUpdate();
				if(r==1) {
					p.print(" Successfully ordered. Product will be sent to your registered Address");
					p.print("<<meta http-equiv=\"refresh\" content=\"3;URL=HomePage.jsp\" />>");
				}
						} }catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	 		
		
		
	 	}
		
	}

}
