package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/cart")
public class cart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public cart() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	//this method enters the products into cart
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	 PrintWriter p=response.getWriter();
	 	String id  =request.getParameter("cart");
	 	String ssid  =request.getParameter("sid");

	 	int pid=Integer.parseInt(id);
	 	int cid=logi.getId();
	 	if(cid==0) {
	 		p.print("please login ");
	 		p.print("<<meta http-equiv=\"refresh\" content=\"3;URL=log.html\" />>");
	 	}else {
	 		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				
				
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
				Statement st=con.createStatement();
				ResultSet res=st.executeQuery("select max(id) from cart");
				while(res.next()) {
					int ida=res.getInt(1);
					ida++;
				PreparedStatement ps=con.prepareStatement("insert into cart values(?,?,?,?)");
				ps.setInt(1, pid);
				ps.setInt(2, cid);
				ps.setInt(3, ida);
				ps.setInt(4, Integer.parseInt(ssid));
				int r=ps.executeUpdate();
				if(r==1) {
					p.print(" Successfully Added into your cart");
					p.print("<<meta http-equiv=\"refresh\" content=\"3;URL=HomePage.jsp\" />>");
				}
				}} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	 		
	 	}
	}

}
