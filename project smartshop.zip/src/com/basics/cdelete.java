package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/cdelete")
public class cdelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public cdelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		}

	// this method delete products in the cart when we click remove
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","6171");
			
			PreparedStatement ps=con.prepareStatement("delete cart where id=?");
			ps.setInt(1, Integer.parseInt(request.getParameter("id")));
		
		
		 int rs=ps.executeUpdate();
		 
		 if(rs==1) {
			
			 p.print("successfully deleted");
				p.print("<<meta http-equiv=\"refresh\" content=\"1;URL=cart.jsp\" />>");

		 }
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
	}

}
