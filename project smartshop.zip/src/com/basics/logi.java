package com.basics;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/logi")
public class logi extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Connection con;
       private PreparedStatement ps;
       static Statement st;
       static ResultSet rs;
      public static String username="";
       public static int id;
       public void init() {
    	   try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "6171");
			st=con.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       }
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p=response.getWriter();

		
	}

	// this method check whether user credentials are valid
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
			PrintWriter p=response.getWriter();
			String type=request.getParameter("type");
			String username1=request.getParameter("user");
			String password=request.getParameter("key");
			try {
			ps=con.prepareStatement("select * from "+type+" where name=? and password=?");
			ps.setString(1,username1);
			ps.setString(2,password);
			rs=ps.executeQuery();


			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
			try {
				if(rs.next()) {
					username=username1;
					id=rs.getInt(1);
					p.print(type);
				if(type.equals("consumer")) {
				p.print("<html>");
				
				p.print("<<meta http-equiv=\"refresh\" content=\"3;URL=HomePage.jsp\" />>");
				
				p.print("</html>");}
				if(type.equals("seller")) {
					p.print("<html>");
				
	

				p.print("<<meta http-equiv=\"refresh\" content=\"0;URL=seller.jsp\" />>"); 
				
				p.print("</html>");
					
				}
				}else {p.print("<html>");
				
				p.print("please enter a valid credentials");
				p.print("<<meta http-equiv=\"refresh\" content=\"3;URL=log.html\" />>");
				
				
				p.print("</html>");
	}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	}
public static int getting(){
	int q;
	try {
		rs=st.executeQuery("select id from seller name="+username);
		 q= rs.getInt(1);
		 return q;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	return 0;
	
	
}

public static int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}
}
